package br.com.pos.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import br.com.pos.conexao.Conexao;
import br.com.pos.entidade.ProdudoBean;

public class DaoProdutos extends DaoGenerica {


	public List listarProdutos() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		List<ProdudoBean> listaDeProdutos = new ArrayList<ProdudoBean>();

		String sql = "select * from produto";
		Connection con = new Conexao().getConnection();
		
		try{
			PreparedStatement stm = (PreparedStatement) con.prepareStatement(sql);
			ResultSet resultado = stm.executeQuery();
			while(resultado.next()) {
				ProdudoBean produtobean = new ProdudoBean();
				produtobean.setNome(resultado.getString("nome"));
				produtobean.setDescricao(resultado.getString("descricao"));
				produtobean.setPreco(resultado.getDouble("preco"));
				listaDeProdutos.add(produtobean);
			}
			
			stm.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return listaDeProdutos;
		
	}
}
