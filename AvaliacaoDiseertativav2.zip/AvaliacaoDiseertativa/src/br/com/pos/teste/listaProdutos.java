package br.com.pos.teste;

import java.sql.SQLException;
import java.util.List;

import br.com.pos.dao.DaoProdutos;
import br.com.pos.entidade.ProdudoBean;

public class listaProdutos {

	public static void main(String[] args) throws IllegalAccessException, ClassNotFoundException, SQLException {
		try {
			listaTodos();
		} catch (InstantiationException e) {
			e.printStackTrace();
		}
		
	
	}
	
	public static void listaTodos() 
			throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		DaoProdutos dao = new DaoProdutos();
		List<ProdudoBean> lista = dao.listarProdutos();
		
	for(ProdudoBean produto: lista)
		System.out.println(produto.getNome());
		
	}
	

}
