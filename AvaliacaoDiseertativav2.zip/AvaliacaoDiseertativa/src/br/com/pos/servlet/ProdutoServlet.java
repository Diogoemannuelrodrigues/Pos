package br.com.pos.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.pos.dao.DaoProdutos;
import br.com.pos.entidade.ProdudoBean;

@WebServlet("/produtoServlet")
public class ProdutoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProdudoBean produto = new ProdudoBean();
		DaoProdutos dao = new DaoProdutos();
		try {
			List<ProdudoBean> listaProdutos = dao.listarProdutos();
			request.setAttribute("produtos", produto);
			request.getRequestDispatcher("/listaProdutos.jsp").forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
								
			
	}
		
	}


